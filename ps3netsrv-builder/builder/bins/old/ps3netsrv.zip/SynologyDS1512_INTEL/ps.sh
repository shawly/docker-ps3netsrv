#!/bin/sh
#DESCRIPTION=This script runs a ps3 net server.

cd /
./volume1/PS3/ps3netsrv /volume1/PS3